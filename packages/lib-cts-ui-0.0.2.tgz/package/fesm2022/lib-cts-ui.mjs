import * as i0 from '@angular/core';
import { Component } from '@angular/core';

class LibCtsUi {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.8", ngImport: i0, type: LibCtsUi, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.8", type: LibCtsUi, isStandalone: true, selector: "lib-lib-cts-ui", ngImport: i0, template: ` <p>lib-cts-ui works!</p> `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.8", ngImport: i0, type: LibCtsUi, decorators: [{
            type: Component,
            args: [{ selector: 'lib-lib-cts-ui', imports: [], template: ` <p>lib-cts-ui works!</p> ` }]
        }] });

/*
 * Public API Surface of lib-cts-ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LibCtsUi };
//# sourceMappingURL=lib-cts-ui.mjs.map

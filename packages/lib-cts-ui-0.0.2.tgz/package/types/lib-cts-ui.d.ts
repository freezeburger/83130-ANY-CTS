import * as i0 from '@angular/core';

declare class LibCtsUi {
    static ɵfac: i0.ɵɵFactoryDeclaration<LibCtsUi, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LibCtsUi, "lib-lib-cts-ui", never, {}, {}, never, never, true, never>;
}

export { LibCtsUi };
